package org.example.validators;

import org.example.ConstraintFactory;
import org.example.exceptions.ConstraintVoilationException;
import org.example.model.Column;
import org.example.model.Constraints;
import org.example.model.DataType;

public class ColumnValidator {

    public ColumnValidator() {
    }

    public static boolean validate(Column column) {
        if(column.getColumnName() == null || column.getColumnName().equals("")) {
            return false;
        }
        if(!(DataType.INTEGER.equals(column.getDataType()) || DataType.STRING.equals(column.getDataType())) ) {
            return false;
        }
        return true;
    }

    public static void validateConstraints(Column column, Object data) throws ConstraintVoilationException {

        // datatype constraints
        ConstraintFactory constraintFactory = new ConstraintFactory();
        Constraints constraints = constraintFactory.getConstraint(column.getDataType());
        constraints.validate(data);

        // extra constraints
        for(Constraints extraConstraints: column.getConstraintLists()) {
            extraConstraints.validate(data);
        }
    }
}
