package org.example.validators;

public interface IValidate {
    void validate() throws Exception;
}
