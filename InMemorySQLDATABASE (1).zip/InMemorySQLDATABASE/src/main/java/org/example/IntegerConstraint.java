package org.example;

import org.example.exceptions.ConstraintVoilationException;
import org.example.exceptions.constraints.IntegerContraintException;
import org.example.exceptions.constraints.OutOfLimitException;
import org.example.model.Constraints;

public class IntegerConstraint  implements Constraints {

    private int lowerLimit = -1024;
    private int upperLimit = 1024;

    public IntegerConstraint() {

    }

    public IntegerConstraint(int lowerLimit, int upperLimit) {
        this.lowerLimit = lowerLimit;
        this.upperLimit = upperLimit;
    }

    @Override
    public void validate(Object data) throws IntegerContraintException {
        try {
//            if(Integer.class.equals(data.getClass())) {
//               throw new
//            }
            if(data == null) {
                return;
            }
            withinLimit((Integer) data);
        } catch (Exception e) {
            throw new IntegerContraintException();
        }
    }

    private void withinLimit(Integer x) throws OutOfLimitException {
        if(x < lowerLimit || x > upperLimit) {
            throw new OutOfLimitException();
        }
    }
}
