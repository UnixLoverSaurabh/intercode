package org.example.model;

import com.sun.istack.internal.NotNull;
import org.example.exceptions.TableAlreadyExistException;
import org.example.exceptions.TableNotExistException;
import org.example.strategy.RandomGenerateId;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Database {

    private Map<String, Table> tableMap;
    private String databaseName = "default";

    public Database(@NotNull String databaseName) {
        this.databaseName = databaseName;
        tableMap = new HashMap<>();
    }

    public void createTable(@NotNull String tableName, List<Column> columnList) {

        if(doesTableExist(tableName)) {
            throw new TableAlreadyExistException();
        }

        // validation of datatye
        Table.validateColumns(columnList);

        // insert table config in the database
        tableMap.put( tableName, new Table(tableName, columnList, new RandomGenerateId()));
    }

    public Map<String, Table> getTables() {
        return tableMap;
    }

    private boolean doesTableExist(@NotNull String tableName) {
        // validation if table exist
        if(tableMap.containsKey(tableName)) {
            return true;
        }
        return false;
    }

    public void deleteTable(@NotNull String tableName) {

        if(!doesTableExist(tableName)) {
            throw new TableNotExistException();
        }
        tableMap.remove(tableName);

    }

    public void insertRowInTable(@NotNull String tableName, @NotNull List<Row> rowList) {
        if(!doesTableExist(tableName)) {
            throw new TableNotExistException();
        }
        Table table = tableMap.get(tableName);
        table.insertRow(rowList);
    }

    public void printTable(@NotNull String tableName) {
        if(!doesTableExist(tableName)) {
            throw new TableNotExistException();
        }
        Table table = tableMap.get(tableName);
        table.printTable();
    }

    public List<Row> filterRowsInTable(@NotNull String tableName, @NotNull Map<Column, Object> filterQuery) {
        if(!doesTableExist(tableName)) {
            throw new TableNotExistException();
        }
        Table table = tableMap.get(tableName);
        return table.filter(filterQuery);
    }


}
