package org.example.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.Getter;
import org.example.validators.ColumnValidator;

import java.util.List;


@AllArgsConstructor
@Getter
public class Column {

    private String columnName;
    private DataType dataType;
    private List<Constraints> constraintLists;

}
