package org.example.model;

import org.example.exceptions.ConstraintVoilationException;

public interface Constraints {

    void validate(Object data) throws ConstraintVoilationException;
}
