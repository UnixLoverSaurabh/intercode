package org.example.model;

public enum DataType {
    STRING,
    INTEGER


//    public boolean contains(Object type) {
//        DataType
//    }
}
