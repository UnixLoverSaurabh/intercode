package org.example.model;

import com.sun.istack.internal.NotNull;
import org.example.exceptions.ConstraintVoilationException;
import org.example.strategy.IGenerateId;
import org.example.validators.ColumnValidator;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

public class Table {

    private List<Row> rowList;
    private String tableName;
    private List<Column> columnList;

    private IGenerateId idGenerator;

    private static ColumnValidator columnValidator;

    public Table(@NotNull String tableName, @NotNull List<Column> columnList, @NotNull IGenerateId idGenerator) {
        this.tableName = tableName;
        this.columnList = columnList;
        this.idGenerator = idGenerator;
        this.columnValidator = new ColumnValidator();
        this.rowList = new ArrayList<>();
    }


    public static void validateColumns(List<Column> columnList) {
        for(Column column: columnList) {
            columnValidator.validate(column);
        }
    }

    public static void validateColumnData(Row row) throws ConstraintVoilationException {
        for(Map.Entry<Column, Object> entry: row.getRowData().entrySet()) {
            columnValidator.validateConstraints(entry.getKey(), entry.getValue());
        }
    }


    void insertRow(@NotNull List<Row> rowList) throws ConstraintVoilationException {
        System.out.println("insertRow rowList " + rowList);
        validatBulk(rowList);
        this.rowList.addAll(rowList);
    }


    List<Row> filter( Map<Column, Object> filterQuery) {

        List<Column> columnList = new ArrayList<>();
        for(Map.Entry<Column, Object> entry: filterQuery.entrySet()) {
            columnList.add(entry.getKey());
        }
        validateColumns(columnList);

        for(Map.Entry<Column, Object> entry: filterQuery.entrySet()) {
            columnValidator.validateConstraints(entry.getKey(), entry.getValue());
        }


        List<Row> filteredRows = new ArrayList<>();

        for(Row row: rowList) {

            boolean allMatch = true;
            for(Map.Entry<Column, Object> entry: filterQuery.entrySet()) {
                Column column = entry.getKey();
                Object value = entry.getValue();

                if(!row.getRowData().get(column).equals(value)) {
                    allMatch = false;
                    break;
                }
            }
            if(allMatch) {
                filteredRows.add(row);
            }
        }
        return filteredRows;

    }

    private static void validatBulk(@NotNull List<Row> rowList) {
        for(Row row: rowList) {
            List<Column> columnList = new ArrayList<>();
            for(Map.Entry<Column, Object> entry: row.getRowData().entrySet()) {
                columnList.add(entry.getKey());
            }
            validateColumns(columnList);
            validateColumnData(row);
        }
    }

    public void printTable() {
        for(Row row: this.rowList) {
            for(Map.Entry<Column, Object> entry: row.getRowData().entrySet()) {
                System.out.printf(entry.getKey() + " " + entry.getValue() + " \n ");
            }
        }
    }


    // TODO: strategy
    Object generatenextId() {
        return idGenerator.nextId();
    }


}
