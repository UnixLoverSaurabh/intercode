package org.example;

import org.example.model.*;
import org.example.strategy.RandomGenerateId;

import javax.naming.ldap.Control;
import java.util.*;

public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");


        Database database = new Database("Employee");

        List<Column> columnList = new ArrayList<>();


        // id column
        List<Constraints> constraints = new ArrayList<>();
        constraints.add(new IsRequiredContraint());

        List<Constraints> constraint2 = new ArrayList<>();

        Column idcolumn = new Column("id", DataType.INTEGER, constraints);
        Column nameColumn = new Column("name", DataType.STRING, constraint2);


        columnList.add(idcolumn);
        columnList.add(nameColumn);

        String tablename = "Accounts";

        // create table
        database.createTable(tablename, columnList);

        System.out.printf("tables list " + database.getTables());


        /// create rows
        List<Row> rowList = new ArrayList<>();
        rowList.add(createRandomData("Sunil", 123));
        rowList.add(createRandomData(null, 234));
//        rowList.add(createRandomData("ieuhfo", null));




        database.insertRowInTable(tablename, rowList);

        database.printTable(tablename);


        // flterquery

        Map<Column, Object> filter = new HashMap<>();
        filter.put(idcolumn, 123);
        filter.put(nameColumn, "Sunil");

        database.filterRowsInTable(tablename, createRandomData("Sunil", 123).getRowData());


    }

    public static Row createRandomData(String name, Integer id) {

        List<Constraints> constraints = new ArrayList<>();
        constraints.add(new IsRequiredContraint());

        List<Constraints> constraint2 = new ArrayList<>();

        Column idcolumn = new Column("id", DataType.INTEGER, constraints);
        Column nameColumn = new Column("name", DataType.STRING, constraint2);


        Row row = new Row();
        Map<Column, Object> rowData = new HashMap<>();
        rowData.put(idcolumn, id);


        rowData.put(nameColumn, name);
        row.setRowData(rowData);
        System.out.printf("createRandomData " + row);
        return row;
    }
}
