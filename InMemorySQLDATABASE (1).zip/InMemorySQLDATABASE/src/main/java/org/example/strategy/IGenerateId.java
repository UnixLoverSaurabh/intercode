package org.example.strategy;

public interface IGenerateId {

    Object nextId();
}
