package org.example.strategy;

import java.util.UUID;

public class RandomGenerateId implements IGenerateId{
    @Override
    public String nextId() {
        return UUID.randomUUID().toString();
    }
}
