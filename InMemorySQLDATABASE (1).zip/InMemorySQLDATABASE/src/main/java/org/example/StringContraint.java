package org.example;

import org.example.exceptions.ConstraintVoilationException;
import org.example.exceptions.constraints.IntegerContraintException;
import org.example.exceptions.constraints.OutOfLimitException;
import org.example.exceptions.constraints.StringConstraintException;
import org.example.model.Constraints;

public class StringContraint implements Constraints {

    private int limit = 200;

    public StringContraint() {

    }

    public StringContraint(int limit) {
        this.limit = limit;
    }


    @Override
    public void validate(Object data) throws StringConstraintException {
        try {
            System.out.printf("x " + data);
            if(data == null) {
                return;
            }
            withinLimit((String) data);
        } catch (Exception e) {
            throw new StringConstraintException();
        }
    }

    void withinLimit(String x) throws OutOfLimitException {
        if(x.length() > limit) {
            throw new OutOfLimitException();
        }
    }
}
