package org.example.exceptions;

public class TableNotExistException extends RuntimeException{

    public TableNotExistException() {
        super("Table doesn't exist");
    }
}
