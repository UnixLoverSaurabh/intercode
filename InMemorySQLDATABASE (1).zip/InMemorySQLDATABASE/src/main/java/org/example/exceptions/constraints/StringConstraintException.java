package org.example.exceptions.constraints;

import org.example.exceptions.ConstraintVoilationException;

public class StringConstraintException extends ConstraintVoilationException {
    public StringConstraintException() {
        super(" String exception");
    }
}
