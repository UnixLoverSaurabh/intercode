package org.example.exceptions.constraints;

import org.example.exceptions.ConstraintVoilationException;

public class IntegerContraintException extends ConstraintVoilationException {
    public IntegerContraintException() {
        super("Integer exception");
    }
}
