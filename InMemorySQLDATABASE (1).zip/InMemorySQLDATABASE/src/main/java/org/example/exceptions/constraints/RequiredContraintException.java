package org.example.exceptions.constraints;

import org.example.exceptions.ConstraintVoilationException;

public class RequiredContraintException extends ConstraintVoilationException {
    public RequiredContraintException() {
        super("Required exception");
    }
}
