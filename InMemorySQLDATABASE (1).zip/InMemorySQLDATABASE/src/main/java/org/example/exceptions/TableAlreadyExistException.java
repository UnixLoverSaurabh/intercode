package org.example.exceptions;

public class TableAlreadyExistException extends RuntimeException{

    public TableAlreadyExistException() {
        super("Table already exists");
    }
}
