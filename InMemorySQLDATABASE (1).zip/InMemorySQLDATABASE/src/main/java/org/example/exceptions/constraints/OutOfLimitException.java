package org.example.exceptions.constraints;

import org.example.IntegerConstraint;

public class OutOfLimitException extends IntegerContraintException {

    public OutOfLimitException() {
        super();
    }
}
