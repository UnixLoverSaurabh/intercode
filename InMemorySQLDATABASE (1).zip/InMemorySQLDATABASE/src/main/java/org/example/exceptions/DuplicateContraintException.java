package org.example.exceptions;

public class DuplicateContraintException extends RuntimeException{

    DuplicateContraintException() {
        super("Row already exists with Id");
    }
}
