package org.example.exceptions;

public class ConstraintVoilationException extends RuntimeException{

    public ConstraintVoilationException(String message) {
        super("ConstraintVoilationException :: " + message);
    }
}
