package org.example;

import org.example.model.Constraints;
import org.example.model.DataType;

public class ConstraintFactory {



    public ConstraintFactory() {

    }

    public Constraints getConstraint(DataType dataType) {
        switch (dataType) {
            case STRING:
                return new StringContraint();
            case INTEGER:
                return new IntegerConstraint();
            default:
                throw new IllegalArgumentException("getConstraint exception!");
        }

    }


}
