package org.example;

import org.example.exceptions.constraints.RequiredContraintException;
import org.example.model.Constraints;

public class IsRequiredContraint implements Constraints {
    @Override
    public void validate(Object data) throws RequiredContraintException {
        if(data == null) throw new RequiredContraintException();
    }
}
